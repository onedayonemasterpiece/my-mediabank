// One ordered sender; at most 2.5 seconds of steady-state PCM waiting, never a promise per frame.
// PCM16/16kHz is the Gemini Live wire format. Keep each batch below 16000 base64 bytes.
// A microphone handoff may intentionally contain up to 20 seconds captured while Live starts.
// That seed gets a separate bounded catch-up window; once drained below half the
// normal byte and fragment watermarks, the strict steady-state guards resume.
export function createLiveAudioSender({
  send,
  onTiming=()=>{},
  onError=()=>{},
  now=()=>performance.now(),
  batchMs=40,
  maxQueueMs=2500,
  maxAgeMs=2500,
  maxBootstrapMs=20000,
  speechEndMs=2000,
  speechStartMs=0,
  longSpeechEndMs=null,
  longSpeechAfterMs=null,
  manualActivityDetection=false,
  continuousCapture=false,
  persist=null
}={}){
  let queue=[],preRoll=[],onsetFrames=[],bytes=0,busy=false,closed=false,active=false,quietMs=0,captured=0,suppressed=0,timer=null;
  let activityOpen=false,turnElapsedMs=0,onsetSpanMs=0,onsetVoiceMs=0,onsetQuietMs=0,rejectedOnsets=0;
  let catchup=false,catchupSealed=false,catchupSeedBytes=0;
  let durableBytes=0,durableItems=0,durableChain=Promise.resolve(),durableError=null,lastStagedWasEnd=false;
  if(!Number.isFinite(speechEndMs)||speechEndMs<500||speechEndMs>10000)throw new TypeError('Invalid speechEndMs');
  if(!Number.isFinite(speechStartMs)||speechStartMs<0||speechStartMs>1000)throw new TypeError('Invalid speechStartMs');
  if(continuousCapture&&manualActivityDetection)throw new TypeError('continuousCapture cannot use manualActivityDetection');
  if((longSpeechEndMs===null)!==(longSpeechAfterMs===null))throw new TypeError('Long speech silence settings must be configured together');
  if(longSpeechEndMs!==null&&(!Number.isFinite(longSpeechEndMs)||longSpeechEndMs<speechEndMs||longSpeechEndMs>10000))throw new TypeError('Invalid longSpeechEndMs');
  if(longSpeechAfterMs!==null&&(!Number.isFinite(longSpeechAfterMs)||longSpeechAfterMs<1000||longSpeechAfterMs>600000))throw new TypeError('Invalid longSpeechAfterMs');
  const bytesPerSecond=32000;
  const steadyByteLimit=bytesPerSecond*maxQueueMs/1000;
  const catchupByteLimit=bytesPerSecond*(maxBootstrapMs+maxQueueMs)/1000;
  // Startup handoff can contain thousands of tiny AudioWorklet quanta even when
  // the bounded PCM duration/byte budget is healthy. Keep a separate generous
  // object-count fuse for pathological fragmentation, but let the byte ceiling
  // remain the primary catch-up bound.
  // Render-quantum count is not a duration signal: Chrome can emit hundreds of tiny
  // 16 kHz fragments per second after a 48 kHz AudioWorklet resample. Bytes and
  // age are the authoritative liveness guards; keep only a large fragmentation fuse.
  const steadyItemLimit=4096;
  const maxCatchupItems=32768;
  const catchupExitItemLimit=Math.floor(steadyItemLimit/2);

  const stats=()=>({
    captured_chunks:captured,
    suppressed_chunks:suppressed,
    queued_chunks:queue.filter(x=>x.pcm).length,
    in_flight:busy?1:0,
    queued_pcm_bytes:bytes,
    queued_base64_bytes:Math.ceil(bytes/3)*4,
    oldest_age_ms:queue.some(x=>x.pcm)?Math.round(now()-queue.find(x=>x.pcm).at):0,
    catchup,
    catchup_seed_pcm_bytes:catchupSeedBytes,
    durable_pending_items:durableItems,
    durable_pending_pcm_bytes:durableBytes,
    activity_open:activityOpen,
    turn_elapsed_ms:Math.round(turnElapsedMs),
    continuous_capture:Boolean(continuousCapture),
    speech_start_ms:Math.round(speechStartMs),
    rejected_onsets:rejectedOnsets
  });
  const report=(event,extra={})=>onTiming(event,{...stats(),...extra});
  const rebaseQueuedAge=()=>{
    const at=now();
    for(const item of queue)if(item.pcm)item.at=at;
    for(const item of preRoll)if(item.pcm)item.at=at;
  };
  const maybeFinishCatchup=()=>{
    // Leave room for PCM captured while the next HTTP batch is in flight.
    if(!catchup||!catchupSealed||bytes>steadyByteLimit/2||queue.length>catchupExitItemLimit)return false;
    catchup=false;catchupSealed=false;rebaseQueuedAge();
    report('catchup_end',{seed_pcm_bytes:catchupSeedBytes});
    return true;
  };
  const stop=()=>{
    closed=true;clearTimeout(timer);timer=null;
    queue=[];preRoll=[];onsetFrames=[];bytes=0;catchup=false;catchupSealed=false;
    active=false;activityOpen=false;quietMs=0;turnElapsedMs=0;
    onsetSpanMs=onsetVoiceMs=onsetQuietMs=0;
  };
  const fail=error=>{
    const transportMetrics=error?.metrics&&typeof error.metrics==='object'?error.metrics:{};
    report('transport_error',{...transportMetrics,error_code:String(error?.code??'LIVE_AUDIO_TRANSPORT').slice(0,80)});
    stop();onError(error);
  };

  async function pump(){
    if(closed||busy||!queue.length)return;
    clearTimeout(timer);timer=null;
    maybeFinishCatchup();
    const first=queue[0],parts=[];let size=0,startupCatchup=catchup;
    if(first.activity_start||first.end)queue.shift();
    else{
      if(first.pcm&&!catchup&&now()-first.at>maxAgeMs){
        fail(Object.assign(new Error('Сеть не успевает передавать речь. Запустите Live снова.'),{code:'LIVE_AUDIO_QUEUE_AGE'}));
        return;
      }
      while(queue.length&&queue[0].pcm&&size+queue[0].pcm.byteLength<=11000){
        const item=queue.shift();parts.push(item.pcm);size+=item.pcm.byteLength;bytes-=item.pcm.byteLength;
      }
    }
    const pcm=new Int16Array(size/2);let offset=0;
    for(const part of parts){pcm.set(part,offset);offset+=part.length;}
    busy=true;const at=now();
    const boundary=first.activity_start?'activity_start':first.end?(manualActivityDetection?'activity_end':'audio_stream_end'):null;
    report('post_start',{capture_at_ms:first.at,batch_chunks:parts.length,pcm_bytes:size,queue_age_ms:at-first.at,stream_end:Boolean(first.end),boundary,startup_catchup:startupCatchup});
    try{
      const outbound=first.activity_start
        ?{activity_start:true,captured_at_ms:first.at,age_ms:Math.max(0,now()-first.at)}
        :first.end
          ?(manualActivityDetection
            ?{activity_end:true,captured_at_ms:first.at,age_ms:Math.max(0,now()-first.at)}
            :{audio_stream_end:true,captured_at_ms:first.at,age_ms:Math.max(0,now()-first.at)})
          :{pcm,captured_at_ms:first.at,age_ms:Math.max(0,now()-first.at),startup_catchup:startupCatchup};
      await send(outbound);
      report('post_end',{duration_ms:now()-at,pcm_bytes:size});
    }catch(error){
      if(!closed)fail(error);
    }finally{
      busy=false;
      maybeFinishCatchup();
      if(!closed&&queue.length)schedule();
    }
  }

  function enqueue(item){queue.push(item);bytes+=item.pcm?.byteLength??0;}
  function durableRelease(size){durableBytes=Math.max(0,durableBytes-size);durableItems=Math.max(0,durableItems-1);}
  function stage(item){
    lastStagedWasEnd=Boolean(item.end);
    if(typeof persist!=='function'){enqueue(item);return true;}
    const size=item.pcm?.byteLength??0,copy=item.pcm?{...item,pcm:new Int16Array(item.pcm)}:{...item};
    durableBytes+=size;durableItems++;
    const byteLimit=catchup?catchupByteLimit:steadyByteLimit;
    const itemLimit=catchup?maxCatchupItems:steadyItemLimit;
    const durableBytesExceeded=bytes+durableBytes>byteLimit,durableItemsExceeded=queue.length+durableItems>itemLimit;
    if(durableBytesExceeded||durableItemsExceeded){
      durableRelease(size);
      fail(Object.assign(new Error('Локальное сохранение речи не успевает за микрофоном.'),{code:durableBytesExceeded?'LIVE_AUDIO_DURABLE_BYTES':'LIVE_AUDIO_DURABLE_FRAGMENTS'}));
      return false;
    }
    durableChain=durableChain.then(async()=>{
      if(durableError){durableRelease(size);return;}
      try{
        await persist(copy.end
          ?{audio_stream_end:true,captured_at_ms:copy.at}
          :{pcm:copy.pcm,sample_rate:16000,captured_at_ms:copy.at});
      }catch(error){
        durableError=error;durableRelease(size);if(!closed)fail(error);return;
      }
      durableRelease(size);
      report('durable_commit',{pcm_bytes:size,stream_end:Boolean(copy.end)});
      if(!closed){enqueue(copy);schedule();}
    });
    return true;
  }
  async function drainDurable(){await durableChain;if(durableError)throw durableError;}
  // Seal only an admitted utterance. The same ordered queue owns the boundary;
  // capture/session stay open, and idle/noise/double clicks create no empty turn.
  function endTurn(){
    if(closed||continuousCapture||!active)return false;
    const at=now(),elapsedMs=turnElapsedMs;
    active=false;activityOpen=false;quietMs=0;turnElapsedMs=0;preRoll=[];
    onsetFrames=[];onsetSpanMs=onsetVoiceMs=onsetQuietMs=0;
    if(!stage({end:true,activity_end:manualActivityDetection,at}))return false;
    report('speech_end',{capture_at_ms:at,turn_elapsed_ms:elapsedMs,explicit:true,manual_activity_detection:manualActivityDetection});
    schedule();
    return !closed;
  }
  async function finish(){
    if(!lastStagedWasEnd){
      const at=now();
      active=false;quietMs=0;preRoll=[];turnElapsedMs=0;
      if(manualActivityDetection){
        if(activityOpen){
          activityOpen=false;
          stage({end:true,activity_end:true,at});
          schedule();
        }else if(typeof persist==='function'){
          await persist({audio_stream_end:true,captured_at_ms:at});
        }
      }else{
        stage({end:true,at});
        schedule();
      }
    }
    await drainDurable();
  }
  function schedule(){
    if(closed)return;
    maybeFinishCatchup();
    const byteLimit=catchup?catchupByteLimit:steadyByteLimit;
    const itemLimit=catchup?maxCatchupItems:steadyItemLimit;
    const queueBytesExceeded=bytes>byteLimit,queueItemsExceeded=queue.length>itemLimit;
    if(queueBytesExceeded||queueItemsExceeded){
      fail(Object.assign(new Error('Сеть не успевает передавать речь. Запустите Live снова.'),{code:queueBytesExceeded?'LIVE_AUDIO_QUEUE_BYTES':'LIVE_AUDIO_QUEUE_FRAGMENTS'}));
      return;
    }
    if(busy)return;
    if(queue.some(x=>x.end||x.activity_start)||bytes>=bytesPerSecond*batchMs/1000)void pump();
    else if(queue.length&&!timer)timer=setTimeout(()=>{timer=null;void pump();},Math.max(0,batchMs-(now()-queue[0].at)));
  }

  function push(pcm,rms){
    if(closed)return;
    captured++;const at=now(),duration=pcm.length/16,item={pcm,at};
    if(continuousCapture){
      // Realtime provider-VAD mode: transport every captured PCM frame and let
      // the Live provider own speech boundaries. Local RMS is telemetry only.
      // The stream is sealed only by finish()/explicit session stop.
      stage(item);
      if(captured%12===0)report('capture',{capture_at_ms:at,continuous_capture:true});
      schedule();
      return;
    }
    // Conservative energy gate: 250ms pre-roll preserves onsets; a 2s tail covers
    // provider VAD (700/1200ms tails failed real Gemini audio acceptance).
    // Optional speechStartMs adds bounded onset admission before opening provider
    // activity. Short impulses (keyboard/finger snap) are discarded instead of
    // becoming semantic turns, while accepted speech replays its buffered onset.
    const startThreshold=0.008,continueThreshold=0.003;
    const trimPreRoll=()=>{
      while(preRoll.reduce((n,x)=>n+x.pcm.length/16,0)>250+duration)preRoll.shift();
    };
    const openSpeech=(frames,evidenceMs)=>{
      active=true;turnElapsedMs=0;quietMs=0;
      if(manualActivityDetection){
        activityOpen=true;
        enqueue({activity_start:true,at});
      }
      for(const previous of preRoll)stage(previous);
      preRoll=[];
      for(const frame of frames)stage(frame);
      turnElapsedMs=evidenceMs;
      onsetFrames=[];onsetSpanMs=onsetVoiceMs=onsetQuietMs=0;
      report('speech_start',{capture_at_ms:at,manual_activity_detection:manualActivityDetection,speech_start_evidence_ms:Math.round(evidenceMs)});
    };
    if(active){
      turnElapsedMs+=duration;stage(item);
      if(rms>=continueThreshold){
        quietMs=0;
      }else{
        quietMs+=duration;
        const endMs=longSpeechEndMs!==null&&turnElapsedMs>=longSpeechAfterMs?longSpeechEndMs:speechEndMs;
        if(quietMs>=endMs){
          const elapsedMs=turnElapsedMs;
          active=false;turnElapsedMs=0;
          if(manualActivityDetection)activityOpen=false;
          stage({end:true,activity_end:manualActivityDetection,at});
          report('speech_end',{capture_at_ms:at,speech_end_silence_ms:endMs,turn_elapsed_ms:elapsedMs,manual_activity_detection:manualActivityDetection});
        }
      }
    }else if(speechStartMs===0){
      if(rms>=startThreshold)openSpeech([item],duration);
      else{suppressed++;preRoll.push(item);trimPreRoll();}
    }else{
      if(onsetFrames.length||rms>=startThreshold){
        onsetFrames.push(item);onsetSpanMs+=duration;
        if(rms>=startThreshold){onsetVoiceMs+=duration;onsetQuietMs=0;}
        else onsetQuietMs+=duration;
        if(onsetQuietMs>80){
          if(onsetVoiceMs>0)rejectedOnsets++;
          suppressed+=onsetFrames.length;
          onsetFrames=[];onsetSpanMs=onsetVoiceMs=onsetQuietMs=0;
          preRoll.push(item);trimPreRoll();
        }else if(onsetSpanMs>=speechStartMs&&onsetVoiceMs>=speechStartMs*.55){
          openSpeech(onsetFrames,onsetSpanMs);
        }
      }else{
        suppressed++;preRoll.push(item);trimPreRoll();
      }
    }
    if(captured%12===0)report('capture',{capture_at_ms:at});
    schedule();
  }

  function seed(frames=[]){
    if(closed||catchup)return false;
    if(!Array.isArray(frames))return false;
    const seedBytes=frames.reduce((total,frame)=>total+(frame?.pcm?.byteLength??0),0);
    if(seedBytes>bytesPerSecond*maxBootstrapMs/1000){
      fail(Object.assign(new Error('Стартовый буфер речи превышает допустимый предел.'),{code:'LIVE_AUDIO_BOOTSTRAP_BYTES'}));
      return false;
    }
    catchup=true;catchupSealed=false;catchupSeedBytes=seedBytes;
    report('catchup_start',{seed_pcm_bytes:seedBytes,max_bootstrap_ms:maxBootstrapMs,max_catchup_items:maxCatchupItems});
    for(const frame of frames){
      if(closed)return false;
      if(!(frame?.pcm instanceof Int16Array)||!Number.isFinite(frame?.rms)){
        fail(Object.assign(new Error('Стартовый буфер речи повреждён.'),{code:'LIVE_AUDIO_BOOTSTRAP_INVALID'}));
        return false;
      }
      push(frame.pcm,frame.rms);
    }
    catchupSealed=true;
    maybeFinishCatchup();
    schedule();
    return !closed;
  }

  return {push,seed,endTurn,finish,drainDurable,stop,stats};
}
